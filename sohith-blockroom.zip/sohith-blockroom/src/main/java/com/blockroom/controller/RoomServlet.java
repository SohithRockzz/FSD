package com.blockroom.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.blockroom.model.Room;
import com.blockroom.model.RoomBlocking;
import com.blockroom.service.RoomService;

@Controller
public class RoomServlet {

	@Autowired
	private RoomService roomService;

	static final Logger logger=Logger.getLogger(RoomServlet.class);
	
						//!--------Redirect to the home page--*******//
	@GetMapping("/")
	public String homePage() {
		return "welcome";
	}

					//!--------Method to check the availability of rooms-------!//
	
	@RequestMapping("/checkAvailability")
	public String checkAvailability(@RequestParam("RO_ROOM_NUMBER") String roomNumber, HttpServletRequest request) {

		HttpSession session=request.getSession();
		int room_number = Integer.parseInt(roomNumber);
		int room_id = (int) roomService.getRoom_id(room_number);
		List<RoomBlocking> list = roomService.getRoom_Details(room_id);
		request.setAttribute("checking", true);
		request.setAttribute("listofBooking", list);
		session.setAttribute("bookingDetails", roomNumber);
		session.setAttribute("roomId", room_id);
		return "welcome";
	}
	
							//!--------Method for common operations---------!//
	
	public void getData(HttpServletRequest request) {
		HttpSession session=request.getSession();
		int room_id = (int)session.getAttribute("roomId");
		List<RoomBlocking> list = roomService.getRoom_Details(room_id);
		request.setAttribute("listofBooking", list);
		request.setAttribute("checking", true);
	}

							//!--------Method to book the rooms--------!//
		
	@GetMapping("/bookNow")
	public String bookNow(HttpServletRequest request) throws ParseException, IOException, ServletException {
		HttpSession session=request.getSession();
		String date = request.getParameter("date");
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMMM-yyyy");
		Date booking_date = sdf.parse(date);
		int room_id = (int)session.getAttribute("roomId");
		RoomBlocking roomBlocking = new RoomBlocking();
		roomBlocking.setBooking_status('Y');
		roomBlocking.setBooking_date(booking_date);
		Room room = new Room();
		room.setRoom_id(room_id);
		room.setRoom_number(Integer.parseInt(request.getParameter("roomNo")));
		roomBlocking.setRoom(room);
		roomService.bookRoom(roomBlocking);
		getData(request);
		return "welcome";
	}
	
						//!--------Method to cancel the booking of the room--------!//
	
	@GetMapping("/cancelBooking")
	public String unBookNow(HttpServletRequest request) throws ParseException {
		HttpSession session=request.getSession();
		String booked_date = request.getParameter("date");
		int room_id = (int)session.getAttribute("roomId");
		roomService.cancelBooking(booked_date, room_id);
		getData(request);
		return"welcome";
	}
}
