package com.blockroom.service;

import java.text.ParseException;
import java.util.List;

import com.blockroom.model.RoomBlocking;

public interface RoomService {

	int getRoom_id(int ro_no);
	
	List<RoomBlocking> getRoom_Details(int id);

	void bookRoom(RoomBlocking obj);

	void cancelBooking(String booked_date, int room_id)throws ParseException;

	


}
