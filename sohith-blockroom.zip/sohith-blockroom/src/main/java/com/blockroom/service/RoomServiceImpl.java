package com.blockroom.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import com.blockroom.model.Room;
import com.blockroom.model.RoomBlocking;


@Service
public class RoomServiceImpl implements RoomService {

	static final Logger logger=Logger.getLogger(RoomServiceImpl.class);
	
	@PersistenceContext
	private EntityManager em;
	
	@Override
	@Transactional
	public int getRoom_id(int room_no) {
		Query query=em.createQuery("from Room where RO_ROOM_NUMBER="+room_no );
		Room room=(Room) query.getSingleResult();
		int id=room.getRoom_id();
		logger.info("Room_id is retrived");
		return id;
	}

	@Override
	@Transactional
	public void bookRoom(RoomBlocking obj) {
		// TODO Auto-generated method stub
		em.persist(obj);		
		logger.info("Room is sucessfully booked");
		
	}

	@SuppressWarnings("unchecked")
	@Override
	@Transactional
	public List<RoomBlocking> getRoom_Details(int room_id) {
		Query query=em.createQuery("from RoomBlocking where room_ro_id="+room_id);
		List<RoomBlocking> list=(List<RoomBlocking>)query.getResultList();
		return list;
	}

	@Override
	@Transactional
	public void cancelBooking(String bookedDate, int room_id) throws ParseException {
		// TODO Auto-generated method stub
		SimpleDateFormat sdf=new SimpleDateFormat("dd-MMMM-yyyy");
		Date booked_date=sdf.parse(bookedDate);		
		SimpleDateFormat dfs=new SimpleDateFormat("YYYY-MM-dd HH:mm:SS");
		String s=dfs.format(booked_date);
		Query query=em.createQuery("from RoomBlocking where room_ro_id=:id and ro_date=:date" );
		logger.info("Room is removed sucessfully");
		query.setParameter("id", room_id);
		query.setParameter("date", s);
		RoomBlocking room_blocking=(RoomBlocking) query.getSingleResult();
		em.remove(room_blocking);
		
	}

}
