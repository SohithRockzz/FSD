package com.blockroom.model;


import java.util.Date;


import javax.persistence.*;

@Entity
@Table(name="Room_Blocking")
public class RoomBlocking {

	@Id
	@Column(name="RB_ID")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int booking_id;

	@Column(name="RO_DATE")
	private Date booking_date;
	
	@Column(name="RB_BOOKED")
	private char booking_status;
	
	 @ManyToOne
	 private Room room;


	public int getBooking_id() {
		return booking_id;
	}


	public void setBooking_id(int booking_id) {
		this.booking_id = booking_id;
	}


	public Date getBooking_date() {
		return booking_date;
	}


	public void setBooking_date(Date booking_date) {
		this.booking_date = booking_date;
	}


	public char getBooking_status() {
		return booking_status;
	}


	public void setBooking_status(char booking_status) {
		this.booking_status = booking_status;
	}


	public Room getRoom() {
		return room;
	}


	public void setRoom(Room room) {
		this.room = room;
	}


	public RoomBlocking(int booking_id, Date booking_date, char booking_status, Room room) {
		super();
		this.booking_id = booking_id;
		this.booking_date = booking_date;
		this.booking_status = booking_status;
		this.room = room;
	}
	
	public RoomBlocking() {
		
	}


	
}
