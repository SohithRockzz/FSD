package com.blockroom.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import javax.persistence.Table;

@Entity
@Table(name = "Room")
public class Room {
	
	@Id
	@Column(name="RO_ID")
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int room_id;

	@Column(name="RO_ROOM_NUMBER")
	private int room_number;

	public Room() {
		super();
		
	}

	public int getRoom_id() {
		return room_id;
	}

	public void setRoom_id(int room_id) {
		this.room_id = room_id;
	}

	public int getRoom_number() {
		return room_number;
	}

	public void setRoom_number(int room_number) {
		this.room_number = room_number;
	}

	public Room(int room_id, int room_number) {
		super();
		this.room_id = room_id;
		this.room_number = room_number;
	}
	
	

}
